#include<iostream>
#include<sstream>
#include<conio.h>
#include"quaverstream.h"
#define ARGTC 7
using namespace std;
using namespace QQS;
const char argts[ARGTC][6]=
{
 "-mid","-vid","-wei",
 "-hei","-fps","-ttf",
 "-codr",
};
int main(int x,char*y[])
{
	cout<<"<<==<< QuaverStream 12.1 (2020-8-05) >>==>>"<<endl;
	cout<<" > > [ ©2019~2020 Qishipai MIDI Tech ] < < "<<endl;
	cout<<" _ _ _ _ _ _ Counter Generator _ _ _ _ _ _ "<<endl;
	if(x==1)
	{
		cout<<"用法:"<<endl;
		cout<<"\t"<<y[0]<<" <参数1> <参数2> ......"<<endl;
		cout<<"参数列表："<<endl;
		cout<<"\t-mid=  MIDI文件路径  (必须指定)"<<endl;
		cout<<"\t-vid=  视频文件路径  (必须指定)"<<endl;
		cout<<"\t-ttf=  字体文件路径  (必须指定)"<<endl;
		cout<<"\t-fps=  输出视频帧率  (默认60)"<<endl;
		cout<<"\t-wei=  输出视频宽度  (默认720)"<<endl;
		cout<<"\t-hei=  输出视频高度  (默认60)"<<endl;
		cout<<"\t-codr= 编码器        (默认libx264)"<<endl;
		cout<<"声明:"<<endl;
		cout<<"\t本软件完全免费！"<<endl;
		cout<<"\t严禁任何个人或团体用于恰烂钱！"<<endl;
		return 1;
	}
	int i,j,FPS=60,weigh=720,heigh=60;
	MIDI_FILE dat;
	stringstream conv;
	string tmp,tmp1,fmidi,video,ttf,coder("libx264");
	for(i=1;i<x;++i)
	{
		string argd(y[i]),argt;
		if((j=argd.find('='))!=-1)
		{
			argt.assign(y[i],j);
			argd.assign(y[i],j+1,-1);
			for(j=0;j<ARGTC;++j)
				if(argt.compare(argts[j])==0)
					break;
		}
		conv.str(argd);
		switch(j)
		{
			case(0):fmidi.assign(argd);break;
			case(1):video.assign(argd);break;
			case(2):conv>>weigh;break;
			case(3):conv>>heigh;break;
			case(4):conv>>FPS;break;
			case(5):ttf.assign(argd);break;
			case(6):coder.assign(argd);break;
			default:
				cerr<<"[QQSC]"<<y[i]<<":无效指令！"<<endl;
				return 1;
		}
		conv.clear();
	}
	if(fmidi.size()==0||video.size()==0||ttf.size()==0)
	{
		cerr<<"[QQSC]输入输出相关文件名需要被指定！"<<endl;
		return 1;
	}
	if(!dat.open(fmidi))
	{
		cerr<<"[QQSC]midi文件加载失败！检查路径及格式！"<<endl;
		return 1;
	}
	conv.str("");
	conv<<"ffmpeg -v error -f lavfi -i ";
	conv<<"color=s="<<weigh<<"x"<<heigh<<":c=black";
	conv<<" -vf \"drawtext=fontfile="<<ttf<<":text=";
	tmp.assign(conv.str());
	conv.str("");
	conv<<":fontsize="<<heigh<<":fontcolor=white\"";
	conv<<" -frames:v 1 -f rawvideo -pix_fmt rgba -";
	tmp1.assign(conv.str());
	conv.str("");
	conv<<"ffmpeg -y -hide_banner -f rawvideo -pix_fmt rgba ";
	conv<<"-s "<<weigh<<"x"<<heigh<<" -r "<<FPS;
	conv<<" -i - -pix_fmt yuv420p -crf 12 -c:v "<<coder;
	conv<<" \""<<video<<"\"";
	FILE*rawout=popen(conv.str().c_str(),"w");
	unsigned int pix,note=0;
	double tick,spd=(double)dat.ppnq*2/FPS;
	vector<SPD>::iterator spdptr=dat.slist.begin();
	for(tick=0;tick<=dat.flength;tick+=spd)
	{
		while(spdptr<dat.slist.end()&&spdptr->pos<=tick)
			spd=(double)1e6/(spdptr++)->val*dat.ppnq/FPS;
		while(note<dat.nlist.size()&&dat.nlist[note].sta<tick)
			++note;
		conv.str("");
		conv<<tmp<<note<<"/"<<dat.nlist.size()<<tmp1;
		FILE*rawin=popen(conv.str().c_str(),"r");
		while(fread(&pix,16,1,rawin)==1)
			fwrite(&pix,16,1,rawout);
		pclose(rawin);
		if(kbhit()&&getch()=='q')
			break;
	}
	pclose(rawout);
	cout<<"[QQSC]CHEER!!!!!   乾杯 (￣ε([]~（￣▽￣）~*"<<endl;
	return 0;
}
