#pragma once
#include "Global.h"
class RenderOptions
{
public:
	std::string MidiPath;
	std::string OutputPath;
	int Width = 1920;
	int Height = 1080;
	int CRF = 17;
	double NoteSpeed = 1;
	int KeyboardHeight = Height * 15 / 100;
	int FPS = 60;
	unsigned int SeparateBarColor = 0xFF000080;
	bool FitNotes = true;
};