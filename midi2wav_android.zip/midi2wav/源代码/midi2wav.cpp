#include<cstdio>
#include<cstring>
#include<conio.h>
#include"bass.h"
#include"bassmidi.h"
#include"bassmix.h"
int parg,flgs,thrds,fonts,vois;
float volume;
char tmp[15],*BUF;
FILE*wavf;
HSTREAM CHtmp,CH;
BASS_MIDI_FONT SF[25],SFtmp;
HFX FX;
BASS_DX8_REVERB REV;
BASS_DX8_I3DL2REVERB IREV;
BASS_DX8_ECHO ECH;
BASS_DX8_PARAMEQ EQ;
BASS_DX8_COMPRESSOR CP;
BASS_MIDI_FONTINFO SFI;
WAVEFORMATEX WH;
int main(int x,char*y[]){
	parg=BASS_GetVersion(),flgs=BASS_Mixer_GetVersion();
	printf("\033[36;40;1m< MIDI2WAV by Qishipai~~~2020 >\n@@  BASS v%d.%d.%d.%d  @@\n@@  BASSMIX v%d.%d.%d.%d  @@\033[m\n",(parg&0xff000000)>>24,(parg&0x00ff0000)>>16,(parg&0x0000ff00)>>8,parg&0x000000ff,(flgs&0xff000000)>>24,(flgs&0x00ff0000)>>16,(flgs&0x0000ff00)>>8,flgs&0x000000ff);
	if(x==1){
		printf("\033[33;40;1m命令格式:\n%s <输入文件(*.mid)> <音质参数> <输出文件(*.wav)> <音色库文件数n> <音色库1(*.sf2)> <音色库1参数>......<音色库n(*.sf2)> <音色库n参数> <合成器参数> <音效1> <音效1参数>......<音效n> <音效n参数>\n音质参数: 采样率#采样类型(1=8位整型，2=16位整型，3=32位浮点)\n音色库参数：preset#bank#volume#是否映射入内存(1=yes,0=no)\n合成器参数：每一线程的复音数＃线程数\n可用音效有 Reverb,Echo,ParamEQ,Compressor,I3DL2Reverb\n音效参数说明:\n<Reverb>  HighFreqRTRatio#InGain#ReverbMix#ReverbTime\n<Echo>  Feedback#LeftDelay#RightDelay#WetDryMix#PanDelay\n<ParamEQ>  Bandwidth#Center#Gain\n<Compressor>  Attack#Gain#Predelay#Ratio#Release#Threshold\n<I3DL2Reverb>  lDecayHFRatio#lDecayTime#lDensity#lDiffusion#lHFReference#lReflectionsDelay#lReverbDelay#lRoomRolloffFactor#Reflections#Reverb#Room#RoomHF\n\n简单示例：\n%s /sdcard/a.mid 44100#2 /sdcard/a.wav 1 /sdcard/1.sf2 -1#0#0.2#1 1000#10 Reverb 0.025#0#-20#680\n\n< MIDI2WAV by Qishipai~~~2020 >\033[m\n",y[0],y[0]);
		return 0;}
	if(x<8){
		printf("\033[31;40;1m指令不完整！\n\033[m");
		return 1;}
	if(sscanf(y[2],"%d#%d",&WH.nSamplesPerSec,&flgs)<2||WH.nSamplesPerSec<100){
		printf("\033[31;40;1m无效指令:%s\n\033[m",y[2]);
		return 1;}
	switch(flgs){
		case(1):
			flgs=BASS_SAMPLE_8BITS|BASS_STREAM_DECODE;
			WH.wFormatTag=1,WH.wBitsPerSample=8;
			printf("\033[32;40;1mWAV格式：pcm_s8le,%dHz\033[m\n",WH.nSamplesPerSec);
			break;
		case(2):
			flgs=BASS_STREAM_DECODE;
			WH.wFormatTag=1,WH.wBitsPerSample=16;
			printf("\033[32;40;1mWAV格式：pcm_s16le,%dHz\033[m\n",WH.nSamplesPerSec);
			break;
		case(3):
			flgs=BASS_SAMPLE_FLOAT|BASS_STREAM_DECODE;
			WH.wFormatTag=3,WH.wBitsPerSample=32;
			printf("\033[32;40;1mWAV格式：pcm_f32le,%dHz\033[m\n",WH.nSamplesPerSec);
			break;
		default:
			printf("\033[31;40;1m无效指令:%s\n\033[m",y[2]);
			return 1;}
	if(WH.nSamplesPerSec>192000){
		printf("\033[31;40;1m*警告：过高的采样率可能无法正常播放！\n\033[m");}
	if(WH.nSamplesPerSec<22050){
		printf("\033[31;40;1m*警告：过低的采样率将会影响wav质量！\n\033[m");}
	if(sscanf(y[(parg=5)-1],"%d",&fonts)<1||fonts<1){
		printf("\033[31;40;1m无效指令:%s\n\033[m",y[4]);
		BASS_Free();
		return 1;}
	if(fonts>25){
		printf("\033[31;40;1m音色库数量超过限制(max 25)！\n\033[m");
		BASS_Free();
		return 1;}
	if(x<fonts*2+6){
		printf("\033[31;40;1m指令不完整！\n\033[m");
		BASS_Free();
		return 1;}
	printf("\033[33;40;1m共使用%d个SoundFont：\033[m\n",fonts);
	for(int pfont=0;pfont<fonts;++pfont,parg+=2){
		if(sscanf(y[parg+1],"%d#%d#%f#%d",&SF[pfont].preset,&SF[pfont].bank,&volume,&vois)<4||vois<0||vois>1||volume<0||volume>1){
			printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg+1]);
			BASS_Free();
			return 1;}
		if(!(SF[pfont].font=BASS_MIDI_FontInit(y[parg],vois==1?BASS_MIDI_FONT_MMAP:0))){
			printf("\033[31;40;1mSoundFont文件读取失败！\n文件不存在或不合规范！\n\033[m");
			BASS_Free();
			return 1;}
		BASS_MIDI_FontSetVolume(SF[pfont].font,volume);
		BASS_MIDI_FontGetInfo(SF[pfont].font,&SFI);
		printf("   \033[35;40;1mSoundFont%d：%s\033[m\n     版权信息：%s\n",pfont+1,SFI.name,SFI.copyright);}
	if(sscanf(y[parg],"%d#%d",&vois,&thrds)<2||vois<0||thrds<0){
		printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg]);
		BASS_Free();
		return 1;}
	if(vois>1000){
		printf("\033[31;40;1m单个线程的复音数过多(max 1000)！\n\033[m");
		BASS_Free();
		return 1;}
	if(thrds>10){
		printf("\033[31;40;1m*警告：线程过多可能会导致崩溃！\n\033[m");}
	printf("\n");
	BASS_Init(0,WH.nSamplesPerSec,0,0,NULL);
	CH=BASS_Mixer_StreamCreate(WH.nSamplesPerSec,2,flgs);
	for(int i=0;i<thrds;++i){
		printf("\033[1A\033[33;40;1m初始化线程……\033[36;40;1m「%d/%d」\033[m\n",i+1,thrds);
		if(!(CHtmp=BASS_MIDI_StreamCreateFile(false,y[1],0,0,flgs,0))){
			printf("\033[31;40;1mMIDI文件读取失败！\n文件不存在、不合规范或线程数过多！\n\033[m");
			BASS_Free();
			return 1;}
		if(BASS_MIDI_StreamGetFonts(CHtmp,&SFtmp,1)){
			BASS_MIDI_FontFree(SFtmp.font);}
		BASS_MIDI_StreamSetFonts(CHtmp,SF,fonts);
		for(int j=0;BASS_ChannelSetAttribute(CHtmp,BASS_ATTRIB_MIDI_TRACK_VOL|j,j%thrds==i?1:0);++j);
		BASS_ChannelSetAttribute(CHtmp,BASS_ATTRIB_MIDI_VOICES,vois);
		BASS_ChannelSetAttribute(CHtmp,BASS_ATTRIB_MIDI_SRC,2);
		BASS_Mixer_StreamAddChannel(CH,CHtmp,BASS_STREAM_AUTOFREE);}
	printf("\033[32;40;1m[%s]=>\033[33;40;1m[bassmidi]=\\%d=>[bassmix]=>",y[1],thrds);
	for(thrds=0;(++parg)<x;++thrds){
		if(!strcmp(y[parg],"ParamEQ")){
			if(sscanf(y[++parg],"%f#%f#%f",&EQ.fBandwidth,&EQ.fCenter,&EQ.fGain)<3){
				printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg]);
				BASS_Free();
				return 1;}
			FX=BASS_ChannelSetFX(CH,BASS_FX_DX8_PARAMEQ,thrds);
			if(!BASS_FXSetParameters(FX,&EQ)){
				printf("\033[31;40;1mParamEQ音效出错！\n请检查输入！\n\033[m");
				BASS_Free();
				return 1;}
			printf("\033[35;40;1m[ParamEQ]=>");
			continue;}
		if(!strcmp(y[parg],"Reverb")){
			if(sscanf(y[++parg],"%f#%f#%f#%f",&REV.fHighFreqRTRatio,&REV.fInGain,&REV.fReverbMix,&REV.fReverbTime)<4){
				printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg]);
				BASS_Free();
				return 1;}
			FX=BASS_ChannelSetFX(CH,BASS_FX_DX8_REVERB,thrds);
			if(!BASS_FXSetParameters(FX,&REV)){
				printf("\033[31;40;1mReverb音效出错！\n请检查输入！\n\033[m");
				BASS_Free();
				return 1;}
			printf("\033[35;40;1m[Reverb]=>");
			continue;}
		if(!strcmp(y[parg],"I3DL2Reverb")){
			if(sscanf(y[++parg],"%f#%f#%f#%f#%f#%f#%f#%f#%d#%d#%d#%d",&IREV.flDecayHFRatio,&IREV.flDecayTime,&IREV.flDensity,&IREV.flDiffusion,&IREV.flHFReference,&IREV.flReflectionsDelay,&IREV.flReverbDelay,&IREV.flRoomRolloffFactor,&IREV.lReflections,&IREV.lReverb,&IREV.lRoom,&IREV.lRoomHF)<12){
				printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg]);
				BASS_Free();
				return 1;}
			FX=BASS_ChannelSetFX(CH,BASS_FX_DX8_I3DL2REVERB,thrds);
			if(!BASS_FXSetParameters(FX,&IREV)){
				printf("\033[31;40;1mI3DL2Reverb音效出错！\n请检查输入！\n\033[m");
				BASS_Free();
				return 1;}
			printf("\033[35;40;1m[I3DL2Reverb]=>");
			continue;}
		if(!strcmp(y[parg],"Compressor")){
			if(sscanf(y[++parg],"%f#%f#%f#%f#%f#%f",&CP.fAttack,&CP.fGain,&CP.fPredelay,&CP.fRatio,&CP.fRelease,&CP.fThreshold)<6){
				printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg]);
				BASS_Free();
				return 1;}
			FX=BASS_ChannelSetFX(CH,BASS_FX_DX8_COMPRESSOR,thrds);
			if(!BASS_FXSetParameters(FX,&CP)){
				printf("\033[31;40;1mCompressor音效出错！\n请检查输入！\n\033[m");
				BASS_Free();
				return 1;}
			printf("\033[35;40;1m[Compressor]=>");
			continue;}
		if(!strcmp(y[parg],"Echo")){
			if(sscanf(y[++parg],"%f#%f#%f#%f#%d",&ECH.fFeedback,&ECH.fLeftDelay,&ECH.fRightDelay,&ECH.fWetDryMix,&vois)<5){
				printf("\033[31;40;1m无效指令:%s\n\033[m",y[parg]);
				BASS_Free();
				return 1;}
			ECH.lPanDelay=(bool)vois;
			FX=BASS_ChannelSetFX(CH,BASS_FX_DX8_ECHO,thrds);
			if(!BASS_FXSetParameters(FX,&ECH)){
				printf("\033[31;40;1mEcho音效出错！\n请检查输入！\n\033[m");
				BASS_Free();
				return 1;}
			printf("\033[35;40;1m[Echo]=>");
			continue;}
		printf("\033[31;40;1m%s是未知音效！\n请检查输入！\n\033[m",y[parg]);
		BASS_Free();
		return 1;}
	printf("\033[31;40;1m[%s]\n「按's'键可中断合成」\033[m\n\n",y[3]);
	WH.nBlockAlign=((WH.nChannels=2)*WH.wBitsPerSample)>>3;
	WH.nAvgBytesPerSec=WH.nSamplesPerSec*WH.nBlockAlign;
	if(!(wavf=fopen(y[3],"wb"))){
		printf("\033[31;40;1m创建输出文件失败！\n请检查权限！\n\033[m");
		BASS_Free();
		return 1;}
	fwrite("RIFF\0\0\0\0WAVEfmt \20\0\0\0",20,1,wavf);
	fwrite(&WH,16,1,wavf),fwrite("data\0\0\0\0",8,1,wavf);
	parg=(int)BASS_ChannelBytes2Seconds(CHtmp,BASS_ChannelGetLength(CHtmp,BASS_POS_BYTE));
	snprintf(tmp,15,"%d:%02d」\033[m\n",parg/60,parg%60);
	for(BUF=new char[32768],vois=-1;BASS_ChannelIsActive(CHtmp);vois=parg){
		thrds=BASS_ChannelGetData(CH,BUF,32768);
		parg=(int)BASS_ChannelBytes2Seconds(CH,BASS_ChannelGetPosition(CH,BASS_POS_BYTE));
		if(_kbhit()){
			if(getch()=='s'){
				break;}}
		if(parg!=vois){
			printf("\033[1A     \033[33;40;1m正在合成……\033[32;40;1m「%d:%02d/%s",parg/60,parg%60,tmp);}
		if(fwrite(BUF,thrds,1,wavf)!=1){
			printf("\033[31;40;1m写入文件时失败！\n请检查储存空间剩余！\n\033[m");
			BASS_Free();
			return 1;}}
	delete BUF;
	fflush(wavf),thrds=ftell(wavf)-8;
	fseek(wavf,4,SEEK_SET),fwrite(&thrds,1,4,wavf);
	fseek(wavf,40,SEEK_SET),thrds-=36;
	fwrite(&thrds,1,4,wavf),fflush(wavf);
	puts("\n\033[1A\033[35;40;1m完成！\033[m");
	fclose(wavf);
	BASS_Free();
	return 0;}
//./midi2wav /sdcard/'5K 5,555,555 notes by The Atom Bomb.mid' 44100#2 /sdcard/1.wav 1 /sdcard/SoundFonts/GeneralUser-GS-v1.471.sf2 -1#0#0.1 1000#15 Reverb 0.005#0#-10#1280